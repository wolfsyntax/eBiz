Rails.application.routes.draw do
  
  get 'logout.do'	=> "sessions#destroy", :as => "logout"
  get 'login.do'	=> "sessions#new", :as => "login"

  get 'signup.php'	=> "users#new", :as => "signup"
  
  root :to => "users#new"
  
  resources :users
  resources :sessions
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end

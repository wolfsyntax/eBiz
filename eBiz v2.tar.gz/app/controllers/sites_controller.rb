class SitesController < ApplicationController
  def about
  end

  def index
  end

  def support
  end
end

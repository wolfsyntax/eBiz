Rails.application.routes.draw do
  
  get 'sites/about'

  get 'sites/index'

  get 'sites/support'

  get 'index.html'	=> "users#index"
  
  get 'logout.do'	=> "sessions#destroy", :as => "logout"
  get 'login.do'	=> "sessions#create", :as => "login"

  #delete record
  get '/:id/delete' => "users#destroy"

  get 'signup.php'	=> "users#new", :as => "signup"
  get '/:id/view'	=> "users#view"

  get '/dashboard'	=> "users#main"
  root :to => "users#new"
  
  resources :users
  resources :sessions
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
